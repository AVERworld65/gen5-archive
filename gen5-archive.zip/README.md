# 第五世代対戦アーカイブ

`index.html` をブラウザーで開くと試作版を閲覧できます。ビルドやAPIキーは不要です。

## GitHub Pagesで公開

このフォルダーのファイルをリポジトリのルートに置きます。GitHubの Settings → Pages で Deploy from a branch を選択し、公開するブランチの /(root) を指定します。


## 公開済みのサイトを更新

1. 最新のZIPを展開します。デザイン更新だけの場合は、展開先の app.js、all-parties.js、parties.html、tournament.html、style.css の5ファイルが対象です。
2. 既存の [GitHubリポジトリ](https://github.com/AVERworld65/gen5-archive) の Code タブで main を開き、Add file → Upload files を選びます。
3. 5ファイルをまとめてドラッグし、同名ファイルの更新として Commit changes を押します。裏で公開処理が始まります。
4. Actions で Pages の公開が完了したら、[公開サイト](https://averworld65.github.io/gen5-archive/) を開きます。古い表示が残る場合は Ctrl + F5 で再読み込みし、トップ・大会詳細・全登録パーティを確認します。
## 大会を追加・訂正

スプレッドシートを原本に、公開項目だけを `data.js` の `tournaments` に反映します。

- 開催日、ルール、出典URLを追加します。大会やサイドイベントごとに異なる `id` を使います。
- ルールは `single`（BW2シングル）、`double`（BW2ダブル）、`christmas`（クリスマスカップ）のいずれかです。
- `kp` は「ポケモン集計」のポケモン名とKP列です。
- `parties` は結果順の順位・公開用ハンドル名・登録6匹です。フォルム表記はKP表と揃えます。
- トップの一覧、絞り込み、追加した大会の詳細を確認してから公開ブランチへ反映します。

第3回関東BWオフの掲載内容は [大会結果報告](https://pokemon-bw-offline.blog.jp/archives/15977415.html) を参照しています。

## 登録パーティと構築記事

- 全登録パーティは `all-parties-data.js` に大会IDとハンドル名・登録6匹を追加します。
- KKPは登録6匹それぞれのKPの合計です。同点の全登録パーティはデータの記載順になります。
- 構築記事は `data.js` の大会データに `articles: { "公開ハンドル名": { title: "記事タイトル", url: "https://example.com/article" } }` を追加します。リンクは上位入賞と全登録の両方に反映されます。